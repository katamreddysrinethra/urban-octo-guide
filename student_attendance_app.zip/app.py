
import streamlit as st
from auth import login_page

st.set_page_config(page_title="Student Attendance System", layout="wide")

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if not st.session_state.logged_in:
    login_page()
else:
    st.title("Student Attendance Management System")
    st.success("Login successful. Use the sidebar to navigate.")
