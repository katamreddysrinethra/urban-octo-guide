
import streamlit as st
import hashlib
from database import get_connection

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def login_page():
    st.title("Login")

    tab1, tab2 = st.tabs(["Login", "Register"])

    with tab1:
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")

        if st.button("Login"):
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE email=? AND password=?",
                        (email, hash_password(password)))
            user = cur.fetchone()
            conn.close()

            if user:
                st.session_state.logged_in = True
                st.rerun()
            else:
                st.error("Invalid credentials")

    with tab2:
        email = st.text_input("Register Email")
        password = st.text_input("Register Password", type="password")

        if st.button("Register"):
            try:
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("INSERT INTO users(email,password) VALUES(?,?)",
                            (email, hash_password(password)))
                conn.commit()
                conn.close()
                st.success("Registration successful")
            except Exception as e:
                st.error(str(e))
