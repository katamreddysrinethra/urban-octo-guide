
import sqlite3

def get_connection():
    return sqlite3.connect("attendance.db", check_same_thread=False)

def init_db():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,
        password TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS students(
        student_id TEXT PRIMARY KEY,
        student_name TEXT NOT NULL,
        course TEXT NOT NULL,
        section TEXT,
        semester TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS attendance(
        attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id TEXT,
        date TEXT,
        course TEXT,
        section TEXT,
        status TEXT
    )
    """)

    conn.commit()
    conn.close()

init_db()
